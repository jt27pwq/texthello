package texttext;

public class text {
	public static void main(String[] args) {
		System.out.println("a");

		System.out.println("a");



	}
}
